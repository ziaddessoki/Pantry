// import React from "react";
// import { Button, Modal } from "react-bootstrap";
// import InstructionsComponent from "./InstructionsComponent";

// const ModalComponent = ({ title, image, id }) => {
//     return (
//             <Modal show={show} onHide={handleClose}>
//                 <Modal.Header closeButton>
//                     <Modal.Title>Instructions for: {title}</Modal.Title>
//                 </Modal.Header>
//                 <Modal.Body>
//                     <InstructionsComponent instructions={recipesInstructions.instructions} />
//                 </Modal.Body>
//                 <Modal.Footer>
//                     <Button variant="secondary" onClick={handleClose}>
//                         Close
//                     </Button>
//                     <Button variant="primary" onClick={handleClose}>
//                         Save Changes
//                     </Button>
//                 </Modal.Footer>
//             </Modal>   
//     )
// }
// export default ModalComponent
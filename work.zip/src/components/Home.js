import React from "react";
import Typography from "@material-ui/core/Typography";

const Profile = () => <Typography variant="h4">Home</Typography>;

export default Profile;
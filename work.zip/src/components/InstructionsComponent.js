import React from "react";

const InstructionsComponent = (props) =>{
    return(
        <div>
            {props.instructions}
        </div>
    )
}

export default InstructionsComponent